#ifndef CLI_CHECKS_UTILS
#define CLI_CHECKS_UTILS

bool is_port_number(const char *number);
bool is_pos_number(const char *number);
bool is_ip_address(const char *ip_address);

#endif  // CLI_CHECKS_UTILS